package ex2;

public interface Pagamento {
    void autorizar(double valor);
}
