package ex3;

public interface Eletrico {
    void carregarBateria();
}
